import sys
import pandas as pd
from sklearn.pipeline import Pipeline
from sklearn.neural_network import MLPClassifier
from sklearn.linear_model import  LogisticRegression
from sklearn.naive_bayes import MultinomialNB
from sklearn.neighbors import KNeighborsClassifier
from sklearn import svm
from sklearn.svm import LinearSVC
from sklearn.tree import DecisionTreeClassifier
from sklearn.linear_model import SGDClassifier
from sklearn.feature_extraction.text import TfidfVectorizer


def detecting_fake_news(train_file,statement,alg):
    result=""
    try:
        stlist=[]
        stlist.clear()
        stlist.append(statement)
        train_news = pd.read_csv(train_file)
        tfidf = TfidfVectorizer(stop_words='english',use_idf=True,smooth_idf=True) #TF-IDF


        if (alg == "Support Vector Machine"):
            print("Start Support Vector Machine Classification")
            svm_pipeline = Pipeline([('SVMTF_IDF', tfidf), ('svm_clf', svm.SVC())])
            svm_pipeline.fit(train_news['Statement'], train_news['Label'])
            result_svm = svm_pipeline.predict(stlist)
            result = result_svm
            print("Completed Support Vector Machine Classification")

        if (alg == "Logistic Regression"):
            print("Start Logistic Regression Classification")
            lgr_pipeline = Pipeline([('LGRTF_IDF', tfidf), ('lgr_clf',LogisticRegression())])
            lgr_pipeline.fit(train_news['Statement'], train_news['Label'])
            result_lgr = lgr_pipeline.predict(stlist)
            result = result_lgr
            print("Completed Logistic Regression Classification")

        if (alg == "Stochastic Gradient Descent"):
            print("Start Stochastic Gradient Descent Classification")
            nn_pipeline = Pipeline([('NNTF_IDF', tfidf), ('sgd_clf', SGDClassifier())])
            nn_pipeline.fit(train_news['Statement'], train_news['Label'])
            result_nn = nn_pipeline.predict(stlist)
            result = result_nn
            print("Completed Stochastic Gradient Descent Classification")


        if (alg == "K-Nearest Neighbor"):
            print("Start K-Nearest Neighbor Classification")
            nn_pipeline = Pipeline([('knnTF_IDF', tfidf), ('knn_clf', KNeighborsClassifier(n_neighbors=3))])
            nn_pipeline.fit(train_news['Statement'], train_news['Label'])
            result_nn = nn_pipeline.predict(stlist)
            result = result_nn
            print("Completed K-Nearest Neighbor Classification")

        if (alg == "Decision Tree"):
            print("Start Decision Tree Classification")
            nn_pipeline = Pipeline([('dtTF_IDF', tfidf), ('dt_clf', DecisionTreeClassifier())])
            nn_pipeline.fit(train_news['Statement'], train_news['Label'])
            result_nn = nn_pipeline.predict(stlist)
            result = result_nn
            print("Completed Decision Tree Classification")


        if (alg == "Linear Support Vector Machine"):
            print("Start LSVM Classification")
            nn_pipeline = Pipeline([('lsvmTF_IDF', tfidf), ('lsvm_clf', LinearSVC())])
            nn_pipeline.fit(train_news['Statement'], train_news['Label'])
            result_nn = nn_pipeline.predict(stlist)
            result = result_nn
            print("Completed LSVM Classification")




        print(result[0])
        return result[0]

    except Exception as e:
        print("Err=" + e.args[0])
        tb = sys.exc_info()[2]
        print(tb.tb_lineno)

#result=detecting_fake_news("train.csv","WOMAN GIVES BIRTH TO BABY girl","Logistic Regression")
#print(result)