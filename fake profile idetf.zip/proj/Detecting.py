

from PyQt5 import QtCore, QtGui, QtWidgets

from Prediction import detecting_fake_news

class Ui_Detecting(object):

    def browse_file(self):
        fileName, _ = QtWidgets.QFileDialog.getOpenFileName(None, "Select File")
        # print(fileName)
        self.lineEdit.setText(fileName)

    def detect(self):
        try:
            training_dataset = self.lineEdit.text()
            statement = self.textEdit.toPlainText()
            alg = self.comboBox.itemText(self.comboBox.currentIndex())
            result = detecting_fake_news(training_dataset, statement, alg)
            self.label_6.setText(str(result))


        except Exception as e:
            print("Error=" + e.args[0])
            tb = sys.exc_info()[2]
            print(tb.tb_lineno)

    def setupUi(self, Dialog):
        Dialog.setObjectName("Dialog")
        Dialog.resize(727, 586)
        Dialog.setStyleSheet("background-color: rgb(85, 170, 127);")
        self.label = QtWidgets.QLabel(Dialog)
        self.label.setGeometry(QtCore.QRect(200, 30, 421, 51))
        self.label.setStyleSheet("color: rgb(255, 255, 255);\n"
"font: 18pt \"Georgia\";")
        self.label.setObjectName("label")
        self.label_2 = QtWidgets.QLabel(Dialog)
        self.label_2.setGeometry(QtCore.QRect(150, 110, 191, 41))
        self.label_2.setStyleSheet("color: rgb(255, 255, 255);\n"
"font: 14pt \"Times New Roman\";")
        self.label_2.setObjectName("label_2")
        self.lineEdit = QtWidgets.QLineEdit(Dialog)
        self.lineEdit.setGeometry(QtCore.QRect(150, 160, 341, 41))
        self.lineEdit.setStyleSheet("font: 14pt \"Times New Roman\";")
        self.lineEdit.setObjectName("lineEdit")
        self.pushButton = QtWidgets.QPushButton(Dialog)
        self.pushButton.setGeometry(QtCore.QRect(520, 160, 111, 41))
        self.pushButton.setStyleSheet("color: rgb(0, 85, 127);\n"
"font: 14pt \"Times New Roman\";\n"
"color: rgb(255, 255, 255);")
        self.pushButton.setObjectName("pushButton")
        self.pushButton.clicked.connect(self.browse_file)
        self.textEdit = QtWidgets.QTextEdit(Dialog)
        self.textEdit.setGeometry(QtCore.QRect(150, 260, 341, 111))
        self.textEdit.setStyleSheet("font: 12pt \"Times New Roman\";")
        self.textEdit.setObjectName("textEdit")
        self.label_3 = QtWidgets.QLabel(Dialog)
        self.label_3.setGeometry(QtCore.QRect(150, 220, 131, 31))
        self.label_3.setStyleSheet("color: rgb(255, 255, 255);\n"
"font: 14pt \"Times New Roman\";")
        self.label_3.setObjectName("label_3")
        self.comboBox = QtWidgets.QComboBox(Dialog)
        self.comboBox.setGeometry(QtCore.QRect(150, 430, 331, 41))
        self.comboBox.setStyleSheet("font: 12pt \"Times New Roman\";")
        self.comboBox.setObjectName("comboBox")
        self.comboBox.addItem("")
        self.comboBox.addItem("")
        self.comboBox.addItem("")
        self.comboBox.addItem("")
        self.comboBox.addItem("")
        self.comboBox.addItem("")
        self.label_4 = QtWidgets.QLabel(Dialog)
        self.label_4.setGeometry(QtCore.QRect(150, 395, 171, 21))
        self.label_4.setStyleSheet("font: 12pt \"Times New Roman\";\n"
"color: rgb(255, 255, 255);")
        self.label_4.setObjectName("label_4")
        self.pushButton_2 = QtWidgets.QPushButton(Dialog)
        self.pushButton_2.setGeometry(QtCore.QRect(540, 430, 131, 41))
        self.pushButton_2.setStyleSheet("font: 75 14pt \"Times New Roman\";\n"
"color: rgb(255, 255, 255);\n"
"background-color: rgb(0, 85, 127);")
        self.pushButton_2.setObjectName("pushButton_2")
        self.pushButton_2.clicked.connect(self.detect)

        self.label_5 = QtWidgets.QLabel(Dialog)
        self.label_5.setGeometry(QtCore.QRect(150, 515, 111, 41))
        self.label_5.setStyleSheet("font: 16pt \"Times New Roman\";\n"
"color: rgb(255, 255, 255);")
        self.label_5.setObjectName("label_5")
        self.label_6 = QtWidgets.QLabel(Dialog)
        self.label_6.setGeometry(QtCore.QRect(260, 522, 121, 31))
        self.label_6.setStyleSheet("font: 14pt \"Times New Roman\";\n"
"color: rgb(255, 255, 255);")
        self.label_6.setObjectName("label_6")

        self.retranslateUi(Dialog)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

    def retranslateUi(self, Dialog):
        _translate = QtCore.QCoreApplication.translate
        Dialog.setWindowTitle(_translate("Dialog", "Detection Fake News"))
        self.label.setText(_translate("Dialog", "Detection of Online Fake News"))
        self.label_2.setText(_translate("Dialog", "Training Dataset        "))
        self.pushButton.setText(_translate("Dialog", "Browse"))
        self.textEdit.setHtml(_translate("Dialog", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:\'Times New Roman\'; font-size:12pt; font-weight:400; font-style:normal;\">\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:\'MS Shell Dlg 2\'; font-size:8.25pt;\"><br /></p></body></html>"))
        self.textEdit.setPlaceholderText(_translate("Dialog", "Type here..."))
        self.label_3.setText(_translate("Dialog", "Statement"))
        self.comboBox.setItemText(0, _translate("Dialog", "Support Vector Machine"))
        self.comboBox.setItemText(1, _translate("Dialog", "Logistic Regression"))
        self.comboBox.setItemText(2, _translate("Dialog", "Stochastic Gradient Descent"))
        self.comboBox.setItemText(3, _translate("Dialog", "K-Nearest Neighbor"))
        self.comboBox.setItemText(4, _translate("Dialog", "Decision Tree"))
        self.comboBox.setItemText(5, _translate("Dialog", "Linear Support Vector Machine"))
        self.label_4.setText(_translate("Dialog", "Select Classifier"))
        self.pushButton_2.setText(_translate("Dialog", "Detect"))
        self.label_5.setText(_translate("Dialog", "Statement :"))
        self.label_6.setText(_translate("Dialog", "wait"))
        

if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    Dialog = QtWidgets.QDialog()
    ui = Ui_Detecting()
    ui.setupUi(Dialog)
    Dialog.show()
    sys.exit(app.exec_())

