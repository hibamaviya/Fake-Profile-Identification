import sys
import pandas as pd
from sklearn.pipeline import Pipeline
import numpy as np
from sklearn.tree import DecisionTreeClassifier
from sklearn.feature_extraction.text import TfidfVectorizer
#import metrics libraries
from sklearn.metrics import classification_report, f1_score, accuracy_score, confusion_matrix
from sklearn.metrics import confusion_matrix
from sklearn.metrics import precision_score
from sklearn.metrics import recall_score
from sklearn.metrics import f1_score
from sklearn.metrics import roc_auc_score


def detecting_dt(train_file,test_file):
    result=""
    try:
        train_news = pd.read_csv(train_file)
        test_news = pd.read_csv(test_file)
        tfidf = TfidfVectorizer(stop_words='english',use_idf=True,smooth_idf=True) #TF-IDF

        print("Start Decision Tree Classification")
        nb_pipeline = Pipeline([('lrgTF_IDF', tfidf), ('lrg_clf', DecisionTreeClassifier())])
        nb_pipeline.fit(train_news['Statement'], train_news['Label'])
        predicted_class= nb_pipeline.predict(test_news["Statement"])
        accuracy= model_assessment_dt(test_news['Label'], predicted_class)
        return  accuracy



    except Exception as e:
        print("Err=" + e.args[0])
        tb = sys.exc_info()[2]
        print(tb.tb_lineno)

def model_assessment_dt(y_test,predicted_class):
    print('DT accuracy')
    #Accuracy = (TP + TN) / ALL
    accuracy=accuracy_score(y_test, predicted_class)*100
    print(accuracy)
    print("Completed Decision Tree Classification")
    return accuracy

