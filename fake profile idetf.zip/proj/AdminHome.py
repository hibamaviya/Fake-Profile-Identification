from PyQt5 import QtCore, QtGui, QtWidgets
from Detecting import Ui_Detecting
from Classifications import Ui_Classifications

class Ui_AdminHome(object):

    def detectStatement(self):
        try:

            self.detect = QtWidgets.QDialog()
            self.ui = Ui_Detecting()
            self.ui.setupUi(self.detect)
            self.detect.show()

        except Exception as e:
            print("Error=" + e.args[0])
            tb = sys.exc_info()[2]
            print(tb.tb_lineno)

    def classify(self):
        try:

            self.clf = QtWidgets.QDialog()
            self.ui = Ui_Classifications()
            self.ui.setupUi(self.clf)
            self.clf.show()

        except Exception as e:
            print("Error=" + e.args[0])
            tb = sys.exc_info()[2]
            print(tb.tb_lineno)

    def setupUi(self, Dialog):
        Dialog.setObjectName("Dialog")
        Dialog.resize(685, 457)
        Dialog.setStyleSheet("background-color: rgb(170, 85, 127);\n"
"background-image: url(../N-Grams/images/fake2.jpg);")
        self.label_2 = QtWidgets.QLabel(Dialog)
        self.label_2.setGeometry(QtCore.QRect(265, 20, 191, 50))
        self.label_2.setStyleSheet("color: rgb(255, 255, 255);\n"
"font: 14pt \"Georgia\";")
        self.pushButton_2 = QtWidgets.QPushButton(Dialog)
        self.pushButton_2.setGeometry(QtCore.QRect(230, 90, 271, 51))
        self.pushButton_2.setStyleSheet("background-color: rgb(170, 85, 0);\n"
"background-color: rgb(0, 85, 127);\n"
"font: 12pt \"Franklin Gothic Demi\";")
        self.pushButton_2.setObjectName("pushButton_2")
        self.pushButton_2.clicked.connect(self.detectStatement)
        self.pushButton = QtWidgets.QPushButton(Dialog)
        self.pushButton.setGeometry(QtCore.QRect(230, 190, 271, 51))
        self.pushButton.setStyleSheet("background-color: rgb(170, 85, 0);\n"
"background-color: rgb(0, 85, 127);\n"
"font: 12pt \"Franklin Gothic Demi\";")
        self.pushButton.setObjectName("pushButton")
        self.pushButton.clicked.connect(self.classify)

        self.retranslateUi(Dialog)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

    def retranslateUi(self, Dialog):
        _translate = QtCore.QCoreApplication.translate
        Dialog.setWindowTitle(_translate("Dialog", "Fake News Detection"))
        self.label_2.setText(_translate("Dialog", "Fake News Detection"))
        self.pushButton_2.setText(_translate("Dialog", "Detection Fake News"))
        self.pushButton.setText(_translate("Dialog", "Classification Results"))



if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    Dialog = QtWidgets.QDialog()
    ui = Ui_AdminHome()
    ui.setupUi(Dialog)
    Dialog.show()
    sys.exit(app.exec_())

